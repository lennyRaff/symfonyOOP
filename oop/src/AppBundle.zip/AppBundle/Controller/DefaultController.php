<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    /**
     * @Route("/app/example", name="homepage")
     */
    public function indexAction()
    {
        return $this->render('app/index.html.twig');
    }

    /**
     * @Route("/app/example/login", name="loginpage")
     */
    public function loginAction()
    {
        $fields = $_POST;
        echo $fields;die();
        $em = $this->getDoctrine()->getManager();
        $user = $en->getRepository('AppBundle:User')->getLogin($fields);
    }
}
